package com.example.photoshot;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.provider.MediaStore;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

class Custom extends View {
    private Paint paint;
    private float x,y,r=5;
    private float x1,y1,x2,y2;
    private Bitmap image;

    public Custom(Context context) {
        super(context);
        Paint paint = new Paint();
        setBackgroundColor(Color.WHITE);
        Resources r = context.getResources();
        //resource폴더에 저장된 그림파일을 Bitmap으로 만들어 리턴
        image = BitmapFactory.decodeResource(r,R.drawable.crop__divider);
        paint.setStrokeWidth(5f);
    }
    @Override
    protected  void onDraw(Canvas canvas){
        canvas.drawBitmap(image,0,0,null);
        canvas.drawCircle(x,y,r,paint);
        canvas.drawCircle(x1,y1,r,paint);
        canvas.drawCircle(x2,y2,r,paint);

        //발 길이
        canvas.drawLine(x,y,x,y+getBottom(), paint);
        // 발 볼
        canvas.drawLine(x1,y1,x2,y2,paint);
        super.onDraw(canvas);
    }
    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        x= event.getX();
        y = event.getY();
        invalidate();
        return true;

    }
}
