// 사진찍으면 화면 중앙에 보이기 + 크롭 가능

package com.example.photoshot;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;
import com.soundcloud.android.crop.Crop;

public class MainActivity extends AppCompatActivity {
        private static final String TAG = "TBT";
        private Boolean isPermission = true;
        private static final int PICK_FROM_CAMERA = 1;
        private File tempFile;

        public static final int sub = 1001; /*다른 액티비티를 띄우기 위한 요청코드(상수)*/

    @Override
        protected void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            TedPermission.with(getApplicationContext())
                    .setPermissionListener(permissionListener)
                    .setRationaleMessage(getResources().getString(R.string.permission_2))
                    .setDeniedMessage(getResources().getString(R.string.permission_1))
                    .setPermissions(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA)
                    .check();

            findViewById(R.id.btnCamera).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // 권한 허용에 동의하지 않았을 경우 토스트 생성.
                    if(isPermission)  takePhoto();
                    else Toast.makeText(view.getContext(), getResources().getString(R.string.permission_2), Toast.LENGTH_LONG).show();
                }
            });

            //그림판
            Custom custom = new Custom(this);
            setContentView(custom);

            //화면 전환
            //Button button = (Button)findViewById(R.id.sub); /*페이지 전환버튼*/
        }

    // 예외 처리
        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {
            if (resultCode != Activity.RESULT_OK) {
                Toast.makeText(this, "취소 되었습니다.", Toast.LENGTH_SHORT).show();
            }
            if (requestCode == PICK_FROM_CAMERA) {
                setImage();
            }
            if (resultCode != RESULT_OK) {
                Toast.makeText(this, "취소 되었습니다.", Toast.LENGTH_SHORT).show();

                if(tempFile != null) {
                    if (tempFile.exists()) {

                        if (tempFile.delete()) {
                            Log.e(TAG, tempFile.getAbsolutePath() + " 삭제 성공");
                            tempFile = null;
                        }
                    }
                }
                return;
            }

            switch (requestCode) {
                case PICK_FROM_CAMERA: {
                    Uri photoUri = Uri.fromFile(tempFile);
                    cropImage(photoUri);
                    break;
                }
                case Crop.REQUEST_CROP: {
                    setImage();
                }
            }
        }

        //카메라에서 가져온 이미지 Crop화면으로 보내기
        private void cropImage(Uri photoUri) {
            Log.d(TAG, "tempFile : " + tempFile);
            //크롭 후 저장할 Uri
            Uri savingUri = Uri.fromFile(tempFile);
            Crop.of(photoUri, savingUri).asSquare().start(this);
        }

    //tempFile 을 bitmap 으로 변환 후 ImageView 에 설정
    private void setImage() {
        ImageView imageView = findViewById(R.id.imageView);
        BitmapFactory.Options options = new BitmapFactory.Options();
        Bitmap originalBm = BitmapFactory.decodeFile(tempFile.getAbsolutePath(), options);
        Log.d(TAG, "setImage : " + tempFile.getAbsolutePath());
        imageView.setImageBitmap(originalBm);
        tempFile = null;

    }

        //카메라에서 이미지 가져오기
        private void takePhoto() {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            try {
                tempFile = createImageFile();
            } catch (IOException e) {
                Toast.makeText(this, "이미지 처리 오류! 다시 시도해주세요.", Toast.LENGTH_SHORT).show();
                finish();
                e.printStackTrace();
            }
            if (tempFile != null) {
                Uri photoUri = Uri.fromFile(tempFile);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                startActivityForResult(intent, PICK_FROM_CAMERA);
            }
        }
        // 카메라에서 찍은 사진을 저장할 파일 생성
        private File createImageFile() throws IOException {

            // 이미지 파일 이름 ( TBT_{시간}_ )
            String timeStamp = new SimpleDateFormat("HHmmss").format(new Date());
            String imageFileName = "TBT_" + timeStamp + "_";

            // 이미지가 저장될 폴더 이름 (TBT)
            File storageDir = new File(Environment.getExternalStorageDirectory() + "/TBT/");
            if (!storageDir.exists()) storageDir.mkdirs();

            // 빈 파일 생성
            File image = File.createTempFile(imageFileName, ".jpg", storageDir);
            return image;
        }
        PermissionListener permissionListener = new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                Toast.makeText(getApplicationContext(),"권한이 허용됨",Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onPermissionDenied(ArrayList<String> deniedPermissions) {
                Toast.makeText(getApplicationContext(),"권한이 거부됨",Toast.LENGTH_SHORT).show();
            }
        };

}
