package com.example.tbtapp;

import java.io.Serializable;

public class UserData implements Serializable {
    private String name;
    private String email;
    private int count;
    private int footSIze;
    private int ballSIze;
    private int angle;

    public UserData(String name, String email, int count, int footSIze, int ballSIze, int angle) {
        this.name = name;
        this.email = email;
        this.count = count;
        this.footSIze = footSIze;
        this.ballSIze = ballSIze;
        this.angle = angle;
    }

    public UserData(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public int getCount() { return count; }
    public void setCount(int count) { this.count = count; }

    public int getFootSIze() { return footSIze; }
    public void setFootSIze(int footSIze) { this.footSIze = footSIze; }

    public int getBallSIze() { return ballSIze; }
    public void setBallSIze(int ballSIze) { this.ballSIze = ballSIze; }

    public int getAngle() { return angle; }
    public void setAngle(int angle) { this.angle = angle; }
}
