package com.example.tbtapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class shoes_whole extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shoes_whole);
    }
}
