package com.example.tbtapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.GridView;

import java.util.ArrayList;

public class shoes_whole extends AppCompatActivity {
    EditText frame_B;
    GridView gridView;
    ArrayList<Foot> list;
    FootListAdapter adapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shoes_whole);
        frame_B = findViewById(R.id.frame_B);
        // RunningShoes
        // HighHeel
        // Loafers
        // Walker
        Intent intent = getIntent();
        String shoes = intent.getStringExtra("shoes");
        frame_B.setText(shoes);
        shoesStyle(shoes);



    }

    void shoesStyle(String shoes){

        if(shoes.equals("whole")) {
            gridView = (GridView)findViewById(R.id.gridView);
            list = new ArrayList<> ();
            adapter = new FootListAdapter(this, R.layout.foot_items,list);
            gridView.setAdapter(adapter);

            // get all data from sqlite
            Cursor cursor = activity_main.DBHelper_image.getAllData("SELECT * FROM FOOT");
            list.clear();
            while(cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String kind = cursor.getString(1);
                String name = cursor.getString(2);
                String price = cursor.getString(3);
                String size = cursor.getString(4);
                String angle = cursor.getString(5);
                byte[] image = cursor.getBlob(6);
                list.add(new Foot(kind, name, price, size, angle, image, id));
            }
            adapter.notifyDataSetChanged();
        }
        else {
            gridView = (GridView)findViewById(R.id.gridView);
            list = new ArrayList<> ();
            adapter = new FootListAdapter(this, R.layout.foot_items,list);
            gridView.setAdapter(adapter);

            // get all data from sqlite
            Cursor cursor = activity_main.DBHelper_image.getAllData("SELECT * FROM FOOT WHERE kind='"+shoes+"'");
            list.clear();
            while(cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String kind = cursor.getString(1);
                String name = cursor.getString(2);
                String price = cursor.getString(3);
                String size = cursor.getString(4);
                String angle = cursor.getString(5);
                byte[] image = cursor.getBlob(6);
                list.add(new Foot(kind, name, price, size, angle, image, id));
            }
            adapter.notifyDataSetChanged();
        }
    }



}
