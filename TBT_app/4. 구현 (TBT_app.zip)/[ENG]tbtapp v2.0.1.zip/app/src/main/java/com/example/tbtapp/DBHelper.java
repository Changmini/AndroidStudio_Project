package com.example.tbtapp;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DBHelper extends SQLiteOpenHelper {

    private static DBHelper sInstance;

    private static final String DB_NAME = "TBT.db";
    private static final int DB_VERSION = 1;
    private static final String SQL_CREATE_ENTRIES =
            String.format("CREATE TABLE %s (%s INTEGER PRIMARY KEY AUTOINCTEMENT, %s TEXT, %s TEXT)",
                    DBContract.tbtEntry.TABLE_NAME,
                    DBContract.tbtEntry._ID,
                    DBContract.tbtEntry.COLUMN_NAME_EMAIL,
                    DBContract.tbtEntry.COLUMN_NAME_PASSWORD);

    public static DBHelper getInstance(Context context) {
        if(sInstance == null) {
            sInstance = new DBHelper(context);
        }
        return sInstance;
    }

    private DBHelper(Context context) {
            super(context, DB_NAME, null, DB_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(SQL_CREATE_ENTRIES);
        }


        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("drop table if exists tbt_user");
            onCreate(db);

        }

}
