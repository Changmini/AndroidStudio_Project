package com.example.tbtapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

public final class DBContract {

    private DBContract() {

    }

    public static class tbtEntry implements BaseColumns {
        public static final String TABLE_NAME = "TBT";
        public static final String COLUMN_NAME_EMAIL = "email";
        public static final String COLUMN_NAME_PASSWORD = "password";
    }
}
