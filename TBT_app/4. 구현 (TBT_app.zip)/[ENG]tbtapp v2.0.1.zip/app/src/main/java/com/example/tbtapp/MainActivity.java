package com.example.tbtapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView TextView_store;
    EditText EditText_email, EditText_password;
    Button Button_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText_email = findViewById(R.id.EditText_email);
        EditText_password = findViewById(R.id.EditTExt_password);
        Button_login = (Button)findViewById(R.id.Button_login);


        Button_login.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = EditText_email.getText().toString();
                String password = EditText_password.getText().toString();

                Intent intent = new Intent(MainActivity.this, LoginResultActivity.class);
                intent.putExtra("email", email);
                intent.putExtra("password", password);
                startActivity(intent);
            }
        });


        // 1. 값을 가져온다 - 검사 (123@gmail.com / 1234)
        // 2. 클릭을 감지한다.
        // 3. 1번의 값을 다음 액티비티로 넘긴다

//        EditText_email.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                Log.d("senti", charSequence+","+i2);
//                Button_login.setClickable(true);
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//
//            }
//        });

    }

    @Override
    public void onBackPressed(){
        String email = EditText_email.getText().toString();
        String password = EditText_password.getText().toString();

        ContentValues contentValues = new ContentValues();
        contentValues.put(DBContract.tbtEntry.COLUMN_NAME_EMAIL,email);
        contentValues.put(DBContract.tbtEntry.COLUMN_NAME_PASSWORD,password);

        SQLiteDatabase db = DBHelper.getInstance(this).getWritableDatabase(); // db 객체
        long newRowId = db.insert(DBContract.tbtEntry.TABLE_NAME,
                null,
                contentValues);
        if(newRowId == -1) {
            Toast.makeText(this,"저장에 문제가 발생하였습니다.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this,"저장에 문제가 발생하였습니다.", Toast.LENGTH_SHORT).show();
        }

        super.onBackPressed();
    }

}
