package com.tistory.black_jin0427.myimagesample;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.os.Environment;
import android.support.v4.widget.ImageViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.tistory.black_jin0427.myimagesample.util.ImageResizeUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;

public class step1 extends AppCompatActivity {
    public float x1,y1,y1_2,x2,y2,x3,y3;
    public double realBallSize, realBalBoll,firstline, secondline;
    ImageView edit_image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step1);
        //사진 가져오기  -> 사진의 크기가 크면 강제종료
        edit_image = (ImageView)findViewById(R.id.edit_image);
        Intent receivedTent = getIntent();
        if(getIntent().hasExtra("byteArray"))
        {
            Bitmap bitmap = BitmapFactory.decodeByteArray(
                    getIntent().getByteArrayExtra("byteArray"),0,getIntent().getByteArrayExtra("byteArray").length);
            edit_image.setImageBitmap(bitmap);
        }
    }
    //사진 위에 그림을 그리고 싶은데 터치 이벤트는 인식하지만 그림이 위에 그려지지않음
    private class MyView extends View {
        Paint mPaint = new Paint();
        public MyView(Context context) {
            super(context);
            ImageView a = findViewById(R.id.edit_image);
            mPaint.setStyle(Paint.Style.STROKE);    //선이 그려지도록
            mPaint.setStrokeWidth(30f); //선의 굵기 지정
            mPaint.setColor(Color.BLUE);    //펜 색상
            mPaint.setStrokeJoin(Paint.Join.ROUND);
        }
        @Override
        public void onDraw(Canvas canvas) {  //화면을 그려주는 메서드
            Bitmap bitmap = ((BitmapDrawable) edit_image.getDrawable()).getBitmap();
            canvas.drawBitmap(bitmap, 0, 0, mPaint);
        }

        public boolean onTouch(Canvas canvas, MotionEvent event) {
            Bitmap bitmap = ((BitmapDrawable) edit_image.getDrawable()).getBitmap();
            canvas.drawBitmap(bitmap, 0, 0, mPaint);

            // 발사이즈
            boolean ch_firstline = true;
            boolean ch_secline = true;

            if (ch_firstline == true && ch_secline == true) {
                x1 = event.getX();
                y1 = event.getY();
                y1_2 = getY() + getBottom();

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        canvas.drawPoint(x1, y1, mPaint);
                        break;

                    case MotionEvent.ACTION_UP:
                        canvas.drawLine(x1, y1, x1, y1_2, mPaint);
                        ch_firstline = false;
                        ch_secline = true;
                        break;
                }
            }

            // 발볼측정
            else if (ch_firstline == false && ch_secline == true) {
                x2 = event.getX();
                y2 = event.getY();
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        canvas.drawPoint(x2, y2, mPaint);
                        break;

                    case MotionEvent.ACTION_UP:
                        ch_secline = false;
                        break;
                }

            } else if (ch_firstline == false && ch_secline == false) {
                x3 = event.getX();
                y3 = event.getY();

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        canvas.drawPoint(x3, y3, mPaint);
                        break;

                    case MotionEvent.ACTION_UP:
                        canvas.drawLine(x2, y2, x3, y3, mPaint);
                        ch_secline = true;
                        break;
                }

                firstline = y1_2 - y1; // 발사이즈
                secondline = x3 - x2;  // 발볼

                int w = edit_image.getWidth();  //이미지의 가로
                int h = edit_image.getHeight();//이미지의 세로

                realBallSize = ((firstline * 297) / h);
                realBalBoll = ((secondline * 210) / w);

            }
            invalidate(); // 화면을 다시그려라
            return true;
        }
    }
}
