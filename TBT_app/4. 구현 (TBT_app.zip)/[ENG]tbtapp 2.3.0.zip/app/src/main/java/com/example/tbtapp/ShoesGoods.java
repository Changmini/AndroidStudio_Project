package com.example.tbtapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ShoesGoods extends AppCompatActivity {

    TextView TextView_get;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shoesgoods);


        //TextView_get = findViewById(R.id.TextView_get);

        Intent intent = getIntent();

        Bundle bundle = intent.getExtras();
        String name = bundle.getString("name");
        String email = bundle.getString("email");
        int a =bundle.getInt("name");
        //TextView_get.setText(email + " / " + password);


        //TextView textView1 = findViewById(R.id.View1);
        //TextView textView2 = findViewById(R.id.View2);

    }


}
