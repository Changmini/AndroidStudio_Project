package com.example.tbtapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class activity_main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView navigationView = findViewById(R.id.bottom_button);

        final main_StateFoot main_stateFoot = new main_StateFoot();
        final ShoesGoodsFragment shoesGoodsFragment = new ShoesGoodsFragment();
        final StretchingFragment stretchingFragment = new StretchingFragment();
        final MymenuFragment mymenuFragment = new MymenuFragment();

        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();
                if(id == R.id.screen_statefoot) {
                    setFragment(main_stateFoot);
                    return true;
                } else if(id == R.id.screen_shoesgods) {
                    setFragment(shoesGoodsFragment);
                    return true;
                }else if(id == R.id.screen_stretching) {
                    setFragment(stretchingFragment);
                    return true;
                }else if(id == R.id.screen_mymenu) {
                    setFragment(mymenuFragment);
                    return true;
                }
                return false;
            }
        });

        navigationView.setSelectedItemId((R.id.screen_statefoot));
    }
    private void setFragment(Fragment fragment){
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.frame, fragment);
        fragmentTransaction.commit();
    }

}
