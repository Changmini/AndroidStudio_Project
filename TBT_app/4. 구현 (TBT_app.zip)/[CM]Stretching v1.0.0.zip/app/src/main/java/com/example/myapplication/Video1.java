package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActionBar;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.MediaController;
import android.widget.VideoView;
import android.content.Context;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.WindowManager;


public class Video1 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video1);

        final VideoView vv = (VideoView) findViewById(R.id.videoView);
        MediaController mediaCon = new MediaController(this);
        mediaCon.setAnchorView(vv);
        Uri video = Uri.parse("android.resource://" + getPackageName() + "/raw/cow");
        vv.setMediaController(mediaCon);
        vv.setVideoURI(video);
        vv.requestFocus();
        vv.start();


    }
}
