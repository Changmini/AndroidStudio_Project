package com.example.tbtapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class activity_main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView navigationView = findViewById(R.id.bottom_button);

        final main_StateFoot main_stateFoot = new main_StateFoot();
        final ShoesGoodsFragment shoesGoodsFragment = new ShoesGoodsFragment();
        final StretchingFragment stretchingFragment = new StretchingFragment();
        final MymenuFragment mymenuFragment = new MymenuFragment();


        //TextView_get = findViewById(R.id.TextView_get);

        Intent intent = getIntent();
        String name = intent.getExtras().getString("name");
        String email = intent.getExtras().getString("email");

        //TextView_get.setText(email + " / " + password);
        //TextView textView1 = findViewById(R.id.View1);
        //TextView textView2 = findViewById(R.id.View2);


        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();
                if(id == R.id.screen_statefoot) {
                    setFragment(main_stateFoot);
                    return true;
                } else if(id == R.id.screen_shoesgods) {
                    //Fragment fragment = new testFragment();//Fragment 생성
                    //Bundle bundle = new Bundle();
                    //bundle.putString("param1", param1); // Key, Value
                    //bundle.putString("param2", param2); // Key, Value
                    //fragment.setArguments(bundle);
                    setFragment(shoesGoodsFragment);
                    return true;
                }else if(id == R.id.screen_stretching) {
                    setFragment(stretchingFragment);
                    return true;
                }else if(id == R.id.screen_mymenu) {
                    setFragment(mymenuFragment);
                    return true;
                }
                return false;
            }
        });

        navigationView.setSelectedItemId((R.id.screen_statefoot));
    }
    private void setFragment(Fragment fragment){
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.frame, fragment);
        fragmentTransaction.commit();
    }

}
