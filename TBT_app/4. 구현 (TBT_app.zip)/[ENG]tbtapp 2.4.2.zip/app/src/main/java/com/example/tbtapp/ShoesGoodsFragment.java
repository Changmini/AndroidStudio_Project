package com.example.tbtapp;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;


/**
 * A simple {@link Fragment} subclass.
 */
public class ShoesGoodsFragment extends Fragment {
    // 신발화면
    ImageButton whole;
    ImageButton runningShoes;
    ImageButton highHeel;
    ImageButton loafers;
    ImageButton walker;

    //찜 모아보기 화면
    ImageButton collection;

    public ShoesGoodsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_shoes_goods, container, false);

        // 신발 화면
        whole = (ImageButton)rootView.findViewById(R.id.whole);
        runningShoes = (ImageButton)rootView.findViewById(R.id.runningShoes);
        highHeel = (ImageButton)rootView.findViewById(R.id.highHeel);
        loafers = (ImageButton)rootView.findViewById(R.id.loafers);
        walker = (ImageButton)rootView.findViewById(R.id.walker);

        // 찜 모아보기 화면
        collection = (ImageButton)rootView.findViewById(R.id.collection);

        // 신발 화면
        whole.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), shoes_whole.class);
                startActivity(intent);
            }
        });
        runningShoes.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), shoes_runningshoes.class);
                startActivity(intent);
            }
        });
        highHeel.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), shoes_highheel.class);
                startActivity(intent);
            }
        });
        loafers.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), shoes_loafers.class);
                startActivity(intent);
            }
        });
        walker.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), shoes_walker.class);
                startActivity(intent);
            }
        });

        // 찜 모아보기 화면
        collection.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), shoes_collection.class);
                startActivity(intent);
            }
        });




        // Inflate the layout for this fragment
        return rootView;


    }

}
