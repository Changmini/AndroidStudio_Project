package com.example.photoshot;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MotionEvent;
import android.view.View;

public class measure_step1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_measure_step1);
        setContentView(new DrawView(this));
    }
    private class DrawView extends View {
        Bitmap myBitmap01, myBitmap02;
        Paint mPaint;

        public DrawView(Context context) {
            super(context);
           // myBitmap01 = BitmapFactory.decodeResource(getResources(), R.drawable.view01);
            mPaint = new Paint();
        }

        protected void onDraw(Canvas canvas) {
            canvas.drawBitmap(myBitmap01, 0, 0, null);
            canvas.drawBitmap(myBitmap02, 150, 300, null);

            mPaint.setColor(Color.GREEN);
            mPaint.setStyle(Paint.Style.STROKE);
            mPaint.setStrokeWidth(3);
            //canvas.drawLine();
        }

}
