package com.example.tbtapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class shoes_highheel extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shoes_highheel);
    }
}
