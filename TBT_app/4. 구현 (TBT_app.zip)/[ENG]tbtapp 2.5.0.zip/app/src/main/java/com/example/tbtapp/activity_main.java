package com.example.tbtapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.Serializable;

public class activity_main extends AppCompatActivity {

    UserData user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Fragment 이동을 위한 선언
        BottomNavigationView navigationView = findViewById(R.id.bottom_button);
        final main_StateFoot main_stateFoot = new main_StateFoot();
        final ShoesGoodsFragment shoesGoodsFragment = new ShoesGoodsFragment();
        final StretchingFragment stretchingFragment = new StretchingFragment();
        final MymenuFragment mymenuFragment = new MymenuFragment();

        // User 이름, 아이디 값 받기
        Intent intent = getIntent();
        String name = intent.getExtras().getString("name");
        String email = intent.getExtras().getString("email");
        user = new UserData(name, email);

        // Fragment 버튼을 통한 화면 이동
        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();
                if(id == R.id.screen_statefoot) {
                    setFragment(main_stateFoot);
                    return true;
                } else if(id == R.id.screen_shoesgods) {
                    setFragment(shoesGoodsFragment);
                    return true;
                }else if(id == R.id.screen_stretching) {
                    setFragment(stretchingFragment);
                    return true;
                }else if(id == R.id.screen_mymenu) {
                    setFragment(mymenuFragment);
                    return true;
                }
                return false;
            }
        });
        // Fragment 초기 화면 설정
        navigationView.setSelectedItemId((R.id.screen_statefoot));

        // main_StateFoot으로 사용자 기본 정보 삽입
        Bundle bundle = new Bundle();
        bundle.putSerializable("user", user); // Key, Value
        main_stateFoot.setArguments(bundle);

        // 설문조사 완료 시
        if(intent.getExtras().getInt("count") >= 0) {
            user.setCount(intent.getExtras().getInt("count"));
        }

        // 발 사이즈 측정을 완료 시



    }

    // Fragment 화면 이동에 필요한 메서드
    private void setFragment(Fragment fragment){
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.frame, fragment);
        fragmentTransaction.commit();
    }
    private void removeFragment(Fragment fragment){
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.remove(fragment);
        fragmentTransaction.commit();
    }
}
