package com.example.photoshot;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;

public class measure_step2 extends AppCompatActivity {
    public boolean ch_firstline = true;
    public boolean ch_secline = true;
    public float x,y,x1,y1,x2,y2,x3,y3;
    public double firstline,secline_a;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_measure_step2);
        setContentView(new DrawView(this));
    }

    private class DrawView extends View {
        Bitmap myBitmap01;
        Paint mPaint;

        public DrawView(Context context) {
            super(context);
            myBitmap01 = BitmapFactory.decodeResource(getResources(), R.drawable.crop__divider);
            mPaint = new Paint();
        }

        protected void onDraw(Canvas canvas) {
            canvas.drawBitmap(myBitmap01, 0, 0, null);

            mPaint.setColor(Color.BLUE);
            mPaint.setStyle(Paint.Style.STROKE);
            mPaint.setStrokeWidth(3);

            // 엄지발톱기준으로수직으로내린선
            if (ch_firstline == true && ch_secline == true)
            {
                x = getX();
                y = getY();

                x1 = x;
                y1 = y + 100;
                canvas.drawLine(x1,y1,x1,y1+500,mPaint);
                ch_firstline = false;
                ch_secline = true;
            }

            // 발툭튀기준옆으로미는선
            else if (ch_firstline == false && ch_secline == true)
            {
                x2 = getX();
                y2 = getY();
                ch_secline = false;

                x3 = x1;
                y3 = y1;
                ch_secline = true;

                firstline = x1 - x2;
                secline_a = y1 - y2;

                //두선의각도계산
                double radline = Math.atan(firstline / secline_a);
                double radline_final = radline * 57.296;   //DB에이값저장
            }

        }
    }
}
