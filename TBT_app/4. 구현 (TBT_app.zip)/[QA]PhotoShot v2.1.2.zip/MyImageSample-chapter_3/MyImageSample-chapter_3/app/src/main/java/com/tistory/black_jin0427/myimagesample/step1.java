package com.tistory.black_jin0427.myimagesample;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.os.Environment;
import android.support.v4.widget.ImageViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.tistory.black_jin0427.myimagesample.util.ImageResizeUtils;

import org.jetbrains.annotations.Nullable;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;

public class step1 extends AppCompatActivity {
    public float x1, y1, y1_2, x2, y2, x3, y3;
    public double realBallSize, realBalBoll, firstline, secondline;
    ImageView edit_image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step1);
        //사진 가져오기  -> 사진의 크기가 크면 강제종료
        /*edit_image = (ImageView) findViewById(R.id.edit_image);
        Intent receivedTent = getIntent();
        if (getIntent().hasExtra("byteArray")) {
            Bitmap bitmap = BitmapFactory.decodeByteArray(
                    getIntent().getByteArrayExtra("byteArray"), 0, getIntent().getByteArrayExtra("byteArray").length);
            edit_image.setImageBitmap(bitmap);
        }*/
    }

    //사진 위에 그림을 그리고 싶은데 터치 이벤트는 인식하지만 그림이 위에 그려지지않음
    public class MyView extends View {
        private Paint mPaint = new Paint();

        public MyView(Context context, @Nullable AttributeSet attrs) {
            super(context, attrs);
            //ImageView a = findViewById(R.id.edit_image);
        }

        @Override
        public void onDraw(Canvas canvas) {  //화면을 그려주는 메서드
            //Bitmap bitmap = ((BitmapDrawable) edit_image.getDrawable()).getBitmap();
            Point point = new Point();
            //canvas.drawBitmap(bitmap, 0, 0, mPaint);
            Paint my = new Paint();
            my.setColor(Color.RED);
            canvas.drawRect(10,10,100,100,my);

        }

        public boolean onTouch(Canvas canvas, MotionEvent event) {
            Bitmap bitmap = ((BitmapDrawable) edit_image.getDrawable()).getBitmap();
            canvas.drawBitmap(bitmap, 0, 0, mPaint);

            boolean ch_firstline = true;
            boolean ch_secline = true;

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:   //터치 시작
                    //발 사이즈
                    if (ch_firstline == true && ch_secline == true) {
                        x1 = event.getX();
                        y1 = event.getY();
                        y1_2 = getY() + getBottom();
                        canvas.drawPoint(x1, y1, mPaint);
                    }

                    //발볼 측정
                    else if (ch_firstline == false && ch_secline == true) {
                        x2 = event.getX();
                        y2 = event.getY();
                        canvas.drawPoint(x2, y2, mPaint);
                    }
                    invalidate();
                    break;

                case MotionEvent.ACTION_UP: //터치 끝
                    //발 사이즈
                    if (ch_firstline = true && ch_secline == true) {
                        canvas.drawLine(x1, y1, x1, y1_2, mPaint);
                        ch_firstline = false;
                        ch_secline = true;
                    }
                    // 발 볼
                    else if (ch_firstline == false && ch_secline == true) {
                        x3 = event.getX();
                        canvas.drawLine(x2, y2, x3, y2, mPaint);
                        ch_secline = false;
                    }
                    invalidate();
                break;
            }

            firstline = y1_2 - y1; // 발사이즈
            secondline = x3 - x2;  // 발볼

            int w = edit_image.getWidth();  //이미지의 가로
            int h = edit_image.getHeight();//이미지의 세로

            realBallSize = ((firstline * 297) / h);
            realBalBoll = ((secondline * 210) / w);

            invalidate();
            return true;
        }
    }
}
