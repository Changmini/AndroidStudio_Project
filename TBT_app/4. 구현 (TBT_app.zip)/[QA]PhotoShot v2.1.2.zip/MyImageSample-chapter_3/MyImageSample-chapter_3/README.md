# MyImageSample

This is a sample that get image from camera and gallery
