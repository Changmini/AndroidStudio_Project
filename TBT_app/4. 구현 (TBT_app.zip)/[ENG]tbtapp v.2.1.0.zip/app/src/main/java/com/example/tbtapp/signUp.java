package com.example.tbtapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class signUp extends AppCompatActivity {

    // 회원가입
    TextView signup, test;
    EditText signup_email, signup_pw, signup_pwcheck, signup_username;
    Button btn_signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        signup_email = findViewById(R.id.signup_email);
        signup_pw = findViewById(R.id.signup_pw);
        signup_pwcheck = findViewById(R.id.signup_pwcheck);
        signup_username = findViewById(R.id.signup_username);
        btn_signup = findViewById(R.id.btn_signup);









//        btn_signup.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent_login = new Intent(signUp.this, MainActivity.class);
//                startActivity(intent_login);
//            }
//        });


        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email  = signup_email.getText().toString();
                String  pw = signup_pw.getText().toString();
                String  pwcheck = signup_pwcheck.getText().toString();
                String  name = signup_username.getText().toString();

                Intent intent = new Intent(signUp.this, MainActivity.class);
                intent.putExtra("email", email);
                intent.putExtra("password", pw);
                intent.putExtra("passwordcheck", pwcheck);
                intent.putExtra("name", name);
                signUp.this.startActivity(intent);
            }
        });






    }
}
