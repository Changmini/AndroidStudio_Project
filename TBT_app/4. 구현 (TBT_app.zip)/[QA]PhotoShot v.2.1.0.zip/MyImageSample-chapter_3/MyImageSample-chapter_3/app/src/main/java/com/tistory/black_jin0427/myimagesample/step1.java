package com.tistory.black_jin0427.myimagesample;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.support.v4.widget.ImageViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;

public class step1 extends AppCompatActivity {
    public float x1,y1,y1_2,x2,y2,x3,y3;
    public double realBallSize, realBalBoll,firstline,secondline;
    ImageView edit_image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step1);
        edit_image = (ImageView)findViewById(R.id.edit_image);
        Intent receivedTent = getIntent();
        if(getIntent().hasExtra("byteArray"))
        {
            Bitmap bitmap = BitmapFactory.decodeByteArray(
                    getIntent().getByteArrayExtra("byteArray"),0,getIntent().getByteArrayExtra("byteArray").length);
            edit_image.setImageBitmap(bitmap);
        }
    }

    private class DrawView extends View {
        Paint mPaint;
        public DrawView(Context context) {
            super(context);
            ImageView a = findViewById(R.id.edit_image);
            mPaint = new Paint();
        }

        protected void onDraw(Canvas canvas) {
            mPaint.setColor(Color.BLUE);
            mPaint.setStyle(Paint.Style.STROKE);
            mPaint.setStrokeWidth(3);

            // 발사이즈
            boolean ch_firstline = true;
            boolean ch_secline = true;
            if (ch_firstline == true && ch_secline == true)
            {
                x1 = getX();
                y1 = getY();
                y1_2 = getY()+getBottom();
                canvas.drawLine(x1,y1,x1,y1_2,mPaint);

                ch_firstline = false;
                ch_secline = true;
            }

            // 발볼측정
            else if (ch_firstline == false && ch_secline == true)
            {
                x2 = getX();
                y2 = getY();
                ch_secline = false;
            }

            else if (ch_firstline == false && ch_secline == false)
            {
                x3 = getX();
                y3 = getY();
                canvas.drawLine(x2,y2,x3,y3,mPaint);
                ch_secline = true;

                firstline = y1_2 - y1; // 발사이즈
                secondline = x3 - x2;  // 발볼

                ImageView a = (ImageView)findViewById((R.id.edit_image));
                FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) a.getLayoutParams();

                params.width = a.getWidth();
                params.height = a.getHeight();

                realBallSize = ((firstline * 297) / params.height);
                realBalBoll = ((secondline * 210) / params.width);

            }
        }
    }
}
