package com.example.tbtapp;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


/**
 * A simple {@link Fragment} subclass.
 */
public class ShoesGoodsFragment extends Fragment {

    ImageView whole;
    public ShoesGoodsFragment() {
        // Required empty public constructor


    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //if(getArguments() != null){
        //    String param1 = getArguments().getString("param1"); // 전달한 key 값 String param2 = getArguments().getString("param2"); // 전달한 key 값
        //}




        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_shoes_goods, container, false);


    }

}
